<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClassName extends Model
{
    protected $guarded=[];
    protected $table='classes';
}
