$(function () {
	$('#dp1').datepicker({
		format: 'dd-mm-yyyy'
	});
	$('#dp2').datepicker({
		format: 'dd-mm-yyyy'
	});
	$('#dp3').datepicker({
		format: 'dd-mm-yyyy'
	});

});