
<?php if(session()->has('success')): ?>

    <div class="page-bar">
        <div class="page-title-breadcrumb">
            <h3 class="alert alert-success"><?php echo e(session()->get('success')); ?></h3>
        </div>
    </div>
<?php elseif(session()->has('error')): ?>
    <div class="page-bar">
        <div class="page-title-breadcrumb">
            <h3 class="alert alert-danger"><?php echo e(session()->get('error')); ?></h3>
        </div>
    </div>

<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\school-ms\resources\views/layouts/assets/_header_msg.blade.php ENDPATH**/ ?>