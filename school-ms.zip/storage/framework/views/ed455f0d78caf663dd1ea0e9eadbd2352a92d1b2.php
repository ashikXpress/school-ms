<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 col-sm-12">
            <div class="card card-box">
                <div class="card-head">
                    <header>Update Class</header>

                </div>
                <div class="card-body " id="bar-parent2">
                    <form action="<?php echo e(route('update.class',$class->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="form-group col-md-8 col-sm-8">
                                <label for="class_name">Class name</label>
                                <input type="text" name="class_name" value="<?php echo e($class->class_name); ?>" id="class_name" class="form-control" placeholder="Enter class name">
                                <span class="text text-danger"><?php echo e($errors->first('class_name')); ?></span>
                            </div>


                            <div class="form-group col-md-8 col-sm-8">
                                <label for="description">Description</label>
                                <textarea class="form-control" name="description" value="<?php echo e($class->description); ?>" id="description" rows="3" placeholder="Enter description"></textarea>
                                <span class="text text-danger"><?php echo e($errors->first('description')); ?></span>
                            </div>

                            <div class="form-group col-md-12">
                                <div class="col-md-9">
                                    <button type="submit" class="btn btn-info btn-lg m-r-20">Update Class</button>
                                    <a href="<?php echo e(route('class.list')); ?>" class="btn btn-default btn-lg">Cancel</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-ms\resources\views/academic/edit_class.blade.php ENDPATH**/ ?>