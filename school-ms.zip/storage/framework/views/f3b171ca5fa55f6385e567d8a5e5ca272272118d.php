<?php $__env->startSection('content'); ?>

<div class="row">
       <div class="col-md-12">
           <div class="card card-topline-red">
               <div class="card-head">
                   <header>Students attendance</header>
                   <div class="tools">
                       <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
                       <a class="t-collapse btn-color fa fa-chevron-up" href="javascript:;"></a>
                       <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                   </div>
               </div>
               <div class="card-body " >
                   <form class="row" action="">

                        <div class="form-group col-md-3 col-sm-3">
                           <label for="class">Class</label>
                           <select class="form-control" name="class" id="class">
                               <option disabled selected>Select class</option>
                               <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <option  value="<?php echo e($class->class_name); ?>" <?php if(old('class') == $class->class_name): ?>selected <?php endif; ?>><?php echo e($class->class_name); ?></option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </select>
                           <span class="text text-danger"><?php echo e($errors->first('class')); ?></span>
                       </div>

                       <div class="form-group col-md-3 col-sm-3">
                           <label for="section">Section</label>
                           <select class="form-control" name="section" id="section">
                               <option disabled selected>Select section</option>
                               <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <option value="<?php echo e($section->section_name); ?>" <?php if(old('section') == $section->section_name): ?>selected <?php endif; ?>><?php echo e($section->section_name); ?></option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </select>
                           <span class="text text-danger"><?php echo e($errors->first('section')); ?></span>
                       </div>
                       <div class="form-group col-md-3 col-sm-3">
                           <label for="shift">Shift</label>
                           <select class="form-control" name="shift" id="shift">
                               <option disabled selected>Select shift</option>
                               <option value="Morning" <?php if(old('shift') == 'Morning'): ?>selected <?php endif; ?>>Morning</option>
                               <option value="Day" <?php if(old('shift') == 'Day'): ?>selected <?php endif; ?>>Day</option>

                           </select>
                           <span class="text text-danger"><?php echo e($errors->first('shift')); ?></span>
                       </div>
                       <div class="col-md-2 padd-less">

                           <button type="submit" class=" btn btn-info">Search</button>

                       </div>

                   </form>

                   <form class="table-scrollable" action="<?php echo e(route('student.attendance')); ?>" method="post">
                       <?php echo csrf_field(); ?>
                       <div id="example4_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer">

                           <div class="row">
                               <div class="col-sm-12">
                                   <table class="table table-striped table-bordered table-hover table-checkable order-column valign-middle dataTable no-footer" id="example4" role="grid" aria-describedby="example4_info">
                                       <thead>
                                       <tr role="row">
                                           <th class="sorting" tabindex="0" aria-controls="example4" rowspan="1" colspan="1" aria-label=": activate to sort column ascending" style="width: 200px;">Status</th>
                                           <th class="sorting" tabindex="0" aria-controls="example4" rowspan="1" colspan="1" aria-label=" Roll No : activate to sort column descending" style="width: 60px;">Class</th>
                                           <th class="sorting" tabindex="0" aria-controls="example4" rowspan="1" colspan="1" aria-label=" Roll No : activate to sort column descending" style="width: 60px;">Roll</th>
                                           <th class="sorting" tabindex="0" aria-controls="example4" rowspan="1" colspan="1" aria-label=" Name : activate to sort column ascending" style="width: 150px;">Name</th>
                                           <th class="sorting" tabindex="0" aria-controls="example4" rowspan="1" colspan="1" aria-label=" Name : activate to sort column ascending" style="width: 80px;">Shift</th>
                                           <th class="sorting" tabindex="0" aria-controls="example4" rowspan="1" colspan="1" aria-label=" Name : activate to sort column ascending" style="width: 20px;">Section</th>
                                           <th class="sorting" tabindex="0" aria-controls="example4" rowspan="1" colspan="1" aria-label=" Name : activate to sort column ascending" style="width: 85px;">Contact number</th>

                                       </tr>
                                       </thead>
                                       <tbody>
                                       <?php if(isset($student_search_lists)): ?>
                                       <?php $__currentLoopData = $student_search_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$student_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                           <tr class="gradeX odd" role="row">
                                               <input type="hidden" name="student_id[]" value="<?php echo e($student_list->id); ?>">
                                               <td>
                                                   <label for="optionsRadios<?php echo e($student_list->id); ?>">Present </label>
                                                       <input type="radio" name="status[<?php echo e($key); ?>]" id="optionsRadios<?php echo e($student_list->id); ?>" checked value="1" >
                                                   <label for="optionsRadios<?php echo e($student_list->id); ?>"> Absent </label>
                                                       <input type="radio" name="status[<?php echo e($key); ?>]"  id="optionsRadios<?php echo e($student_list->id); ?>" value="0" >
                                               </td>

                                               <td class="left"><?php echo e($student_list->class); ?></td>
                                               <td class="left"><?php echo e($student_list->roll); ?></td>
                                               <td><a href=""><?php echo e($student_list->first_name.' '.$student_list->last_name); ?></a></td>
                                               <td><?php echo e($student_list->shift); ?></td>
                                               <td><?php echo e($student_list->section); ?></td>
                                               <td><?php echo e($student_list->contact_number); ?></td>


                                           </tr>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       <?php endif; ?>
                                       </tbody>
                                   </table>
                                   <?php if(isset($attendance_check)): ?>
                                       <h3 class="text text-danger"><?php echo e($attendance_check); ?></h3>
                                   <?php endif; ?>
                               </div>
                           </div>
                           <div class="row">
                               <div class="col-sm-6 col-md-6 ">
                                   <?php if(isset($student_search_lists)): ?>
                                   <p><strong>Total student is <?php echo e($student_search_lists->count()); ?></strong></p>
                                   <button type="submit" class="btn btn-lg btn-info present-btn">Present</button>
                                   <?php endif; ?>

                               </div>
                           </div>
                       </div>
                   </form>


               </div>
           </div>
       </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-ms\resources\views/attendance/student_attendance.blade.php ENDPATH**/ ?>