<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 col-sm-12">
            <div class="card card-box">
                <div class="card-head">
                    <header>Update Exam Term Name</header>
                </div>
                <div class="card-body " id="bar-parent2">
                    <form action="<?php echo e(route('update.exam.term',$exam_term->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="form-group col-md-8 col-sm-8">
                                <label for="exam_term_name">Exam term name</label>
                                <input type="text" name="exam_term_name" value="<?php echo e($exam_term->exam_term_name); ?>" id="exam_term_name" class="form-control" placeholder="Enter exam term name">
                                <span class="text text-danger"><?php echo e($errors->first('exam_term_name')); ?></span>
                            </div>


                            <div class="form-group col-md-12">
                                <div class="col-md-9">
                                    <button type="submit" class="btn btn-info btn-lg m-r-20">Update Exam Term</button>
                                    <a href="<?php echo e(route('exam.term.list')); ?>" class="btn btn-default btn-lg">Cancel</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-ms\resources\views/exam/edit_exam_term.blade.php ENDPATH**/ ?>