<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 col-sm-12">
            <div class="card card-box">
                <div class="card-head">
                    <header>Create class routine</header>
                    <button id="panel-button3"
                            class="mdl-button mdl-js-button mdl-button--icon pull-right"
                            data-upgraded=",MaterialButton">
                        <i class="material-icons">more_vert</i>
                    </button>
                    <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect"
                        data-mdl-for="panel-button3">
                        <li class="mdl-menu__item"><i class="material-icons">assistant_photo</i>Action
                        </li>
                        <li class="mdl-menu__item"><i class="material-icons">print</i>Another action
                        </li>
                        <li class="mdl-menu__item"><i class="material-icons">favorite</i>Something else
                            here</li>
                    </ul>
                </div>
                <div class="card-body " id="bar-parent2">
                    <form action="<?php echo e(route('create.class.routine')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">

                            <div class="form-group col-md-2 col-sm-2">
                                <label for="class">Day</label>
                                <select class="form-control" name="day" id="class">
                                    <option disabled selected>Select day</option>

                                    <option value="Saturday" <?php if(old('day') == 'Saturday'): ?>selected <?php endif; ?>>Saturday</option>
                                    <option value="Sunday" <?php if(old('day') == 'Sunday'): ?>selected <?php endif; ?>>Sunday</option>
                                    <option value="Monday" <?php if(old('day') == 'Monday'): ?>selected <?php endif; ?>>Monday</option>
                                    <option value="Tuesday" <?php if(old('day') == 'Tuesday'): ?>selected <?php endif; ?>>Tuesday</option>
                                    <option value="Wednesday" <?php if(old('day') == 'Wednesday'): ?>selected <?php endif; ?>>Wednesday</option>
                                    <option value="Thursday" <?php if(old('day') == 'Thursday'): ?>selected <?php endif; ?>>Thursday</option>
                                    <option value="Friday" <?php if(old('day') == 'Friday'): ?>selected <?php endif; ?>>Friday</option>
                                </select>

                                <span class="text text-danger"><?php echo e($errors->first('day')); ?></span>
                            </div>
                            <div class="form-group col-md-2 col-sm-2">
                                <label for="class">Class name</label>
                                <select class="form-control classname" name="class" id="class">
                                    <option disabled selected>Select class</option>
                                    <?php $__currentLoopData = $class_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($class_name->class_name); ?>" <?php if(old('class') == $class_name->class_name): ?>selected <?php endif; ?>><?php echo e($class_name->class_name); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <span class="text text-danger"><?php echo e($errors->first('class')); ?></span>
                            </div>

                            <div class="form-group col-md-2 col-sm-2">
                                <label for="class">Period</label>
                                <select class="form-control" name="period" id="class">
                                    <option disabled selected>Select period</option>
                                    <option value="1st" <?php if(old('period') == '1st'): ?>selected <?php endif; ?>>1st</option>
                                    <option value="2nd" <?php if(old('period') == '2nd'): ?>selected <?php endif; ?>>2nd</option>
                                    <option value="3rd" <?php if(old('period') == '3rd'): ?>selected <?php endif; ?>>3rd</option>
                                    <option value="4th" <?php if(old('period') == '4th'): ?>selected <?php endif; ?>>4th</option>
                                    <option value="5th" <?php if(old('period') == '5th'): ?>selected <?php endif; ?>>5th</option>
                                    <option value="6th" <?php if(old('period') == '6th'): ?>selected <?php endif; ?>>6th</option>
                                    <option value="7th" <?php if(old('period') == '7th'): ?>selected <?php endif; ?>>7th</option>
                                    <option value="8th" <?php if(old('period') == '8th'): ?>selected <?php endif; ?>>8th</option>
                                </select>

                                <span class="text text-danger"><?php echo e($errors->first('period')); ?></span>
                            </div>
                            <div class="form-group col-md-2 col-sm-2">
                                <label>Subject</label>
                                <select class="form-control" name="subject"  id="designation">

                                    <option disabled selected>Select subject</option>
                                    <?php $__currentLoopData = $all_subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($subject->subject_name); ?>" <?php if(old('subject') == $subject->subject_name): ?>selected <?php endif; ?>><?php echo e($subject->subject_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text text-danger"><?php echo e($errors->first('subject')); ?></span>
                            </div>

                            <div class="form-group col-md-2 col-sm-2">
                                <label for="start_time">Start time</label>
                                <input type="text" name="start_time" value="<?php echo e(old('start_time')); ?>"  id="start_time" class="form-control" placeholder="8:00am">
                                <span class="text text-danger"><?php echo e($errors->first('start_time')); ?></span>
                            </div>
                            <div class="form-group col-md-2 col-sm-2">
                                <label for="end_time">End time</label>
                                <input type="text" name="end_time" value="<?php echo e(old('end_time')); ?>" id="end_time" class="form-control timepicker" placeholder="8:45am">
                                <span class="text text-danger"><?php echo e($errors->first('end_time')); ?></span>
                            </div>

                            <div class="form-group col-md-2 col-sm-2">
                                <label for="room_number">Room number</label>
                                <input type="text" name="room_number" value="<?php echo e(old('room_number')); ?>" id="room_number" class="form-control" placeholder="Room number">
                                <span class="text text-danger"><?php echo e($errors->first('room_number')); ?></span>
                            </div>


                            <div class="form-group col-md-2 col-sm-2">
                                <label for="class">Teacher name</label>
                                <select class="form-control" name="teacher_name" id="class">
                                    <option disabled selected>Select teacher</option>
                                    <?php $__currentLoopData = $all_teacher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($teacher->first_name.' '.$teacher->last_name); ?>" <?php if(old('teacher_name') == $teacher->first_name.' '.$teacher->last_name): ?>selected <?php endif; ?>><?php echo e($teacher->first_name.' '.$teacher->last_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <span class="text text-danger"><?php echo e($errors->first('teacher_name')); ?></span>
                            </div>
                            <div class="form-group col-md-2 col-sm-2">
                                <label>Section (*Optional)</label>
                                <select class="form-control" name="section" id="section">
                                    <option disabled selected>Select section</option>
                                    <?php $__currentLoopData = $all_section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($section->section_name); ?>" <?php if(old('section') == $section->section_name): ?>selected <?php endif; ?>><?php echo e($section->section_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text text-danger"><?php echo e($errors->first('section')); ?></span>
                            </div>
                            <div class="form-group col-md-2 col-sm-2">
                                <label>Shift (*Optional)</label>
                                <select class="form-control" name="shift" id="shift">
                                    <option disabled selected>Select Group</option>
                                    <option value="Day" <?php if(old('shift') == 'Day'): ?>selected <?php endif; ?>>shift</option>
                                    <option value="Morning" <?php if(old('shift') == 'Morning'): ?>selected <?php endif; ?>>Morning</option>

                                </select>
                                <span class="text text-danger"><?php echo e($errors->first('shift')); ?></span>
                            </div>

                            <div class="form-group col-md-2 col-sm-2">
                                <label>Group (*Optional)</label>
                                <select class="form-control" name="group" id="group">
                                    <option disabled selected>Select Group</option>
                                    <option value="Humanity" <?php if(old('group') == 'Humanity'): ?>selected <?php endif; ?>>Humanity</option>
                                    <option value="Business_studies" <?php if(old('group') == 'Business_studies'): ?>selected <?php endif; ?>>Business studies</option>
                                    <option value="Science" <?php if(old('group') == 'Science'): ?>selected <?php endif; ?>>Science</option>

                                </select>
                                <span class="text text-danger"><?php echo e($errors->first('group')); ?></span>
                            </div>

                            <div class="form-group col-md-2 col-sm-2">
                                <label for="academic_year">Academic year</label>
                                <input type="text" name="academic_year" value="<?php echo e(old('academic_year')); ?>" id="academic_year" class="form-control yearpicker" placeholder="Academic year">
                                <span class="text text-danger"><?php echo e($errors->first('academic_year')); ?></span>
                            </div>


                            <div class="form-group col-md-12">
                                <div class="col-md-9">
                                    <button type="submit" class="btn btn-info  m-r-20">Create class routine</button>
                                    <a class="btn btn-default">Cancel</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-ms\resources\views/academic/create_class_routine.blade.php ENDPATH**/ ?>