<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-sm-12">
            <div class="card-box">
                <div class="card-head">
                    <header>Student Result</header>

                </div>

                <div class="card-body">
                    <form class="row" action="">

                        <div class="form-group col-md-3 col-sm-3">
                            <label for="class">Student</label>
                            <select class="form-control" name="student_id" id="class">
                                <option disabled selected>Select student</option>
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($student->id); ?>"><?php echo e($student->id_number); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        </div>

                        <div class="col-md-2 padd-less">

                            <button type="submit" class=" btn btn-info">Search</button>

                        </div>

                    </form>

                    <table class="col-md-8 mdl-data-table">
                        <thead>
                            <tr>
                                <td colspan="1" rowspan="2"><img style="width:50px" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRqCnWcgPnoRaRRPc-gMlwpfDvNcMFCNf5BcBe9tlcdoO9LWdmW" alt=""></td>
                                <td colspan="4"><h4>Dhaka Ideal model School, Dhaka</h4></td>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if(isset($std)): ?>
                        <tr>
                            <td colspan="1">Name: <?php echo e($std->first_name.' '.$std->last_name); ?></td>
                            <td colspan="1">Class: <?php echo e($std->class); ?></td>
                            <td colspan="1">Roll: <?php echo e($std->roll); ?></td>
                            <td colspan="2">Reg: <?php echo e($std->reg); ?></td>

                        </tr>
                        <?php endif; ?>
                        <tr>
                            <td>Sl</td>
                            <td>Subject Name</td>
                            <td>Marks</td>
                            <td>Grade Point</td>
                            <td>Grade</td>
                        </tr>
                        <?php if(isset($marks)): ?>
                        <?php $__currentLoopData = $marks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($mark->subject_name); ?></td>
                            <td><?php echo e($mark->marks); ?></td>
                            <td><?php echo e($mark->grade_point); ?></td>
                            <td><?php echo e($mark->grade); ?></td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php endif; ?>
                        <tfooter>
                            <tr>
                                <th>Total</th>
                                <th></th>
                                <th></th>
                                <th></th>

                                <?php if(isset($marks)): ?>
                                <th>GPA: <?php echo e($marks->sum('grade_point')/$marks->count()); ?></th>
                                <?php endif; ?>




                            </tr>
                        </tfooter>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-ms\resources\views/result/result_report.blade.php ENDPATH**/ ?>