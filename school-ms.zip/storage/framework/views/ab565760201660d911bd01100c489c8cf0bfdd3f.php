<?php $__env->startSection('content'); ?>
    <!-- panel-login start -->
    <div class="authfy-panel panel-login text-center active">
        <div class="authfy-heading">
            <h3 class="auth-title">Login to your account</h3>
            <?php if(session()->has('error')): ?>
                        <span class="text text-danger">
                             <?php echo e(session()->get('error')); ?>

                         </span>
            <?php endif; ?>
            <?php if(session()->has('success')): ?>
                <span class="text text-success">
                             <?php echo e(session()->get('success')); ?>

                         </span>
            <?php endif; ?>
        </div>
        <!-- social login buttons start -->

        <div class="row">
            <div class="col-xs-12 col-sm-12">
                <form  class="loginForm" action="<?php echo e(route('employee.reset.password',$token)); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="pwdMask">
                        <input type="password" class="form-control password" name="new_password" value="<?php echo e(old('new_password')); ?>" placeholder="New password">
                        <span class="text text-danger"><?php echo e($errors->first('new_password')); ?></span>
                        <span class="fa fa-eye-slash pwd-toggle"></span>
                    </div>
                    <div class="pwdMask">
                        <input type="password" class="form-control password" name="confirm_password" value="<?php echo e(old('confirm_password')); ?>" placeholder="Confirm password">
                        <span class="text text-danger"><?php echo e($errors->first('confirm_password')); ?></span>
                        <span class="fa fa-eye-slash pwd-toggle"></span>
                    </div>
                    <div class="row remember-row">

                        <div class="col-xs-6 col-sm-6 col-md-offset-6">
                            <p class="forgotPwd">
                                <a  href="<?php echo e(route('login.form')); ?>">Login to your account?</a>
                            </p>
                        </div>
                    </div> <!-- ./remember-row -->
                    <div class="form-group">
                        <button class="btn btn-lg btn-primary btn-block" type="submit">Password reset</button>
                    </div>
                </form>
            </div>
        </div>
    </div> <!-- ./panel-login -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.employee_auth_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-ms\resources\views/admin/auth/employee_password_reset.blade.php ENDPATH**/ ?>