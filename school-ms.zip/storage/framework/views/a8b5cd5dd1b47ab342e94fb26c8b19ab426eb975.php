<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="card card-topline-aqua">
                <div class="card-body no-padding height-9">
                    <div class="row">
                        <div class="profile-userpic student-profile col-md-4">
                            <img src="<?php echo e(asset($employee->photo)); ?>" class="img-responsive" alt="">
                        </div>
                    </div>
                    <div class="row">

                        <div class="col-md-1"></div>
                        <ul class="list-group col-md-10">
                            <li class="list-group-item">
                                <b>Name: </b><?php echo e($employee->first_name.' '.$employee->last_name); ?></li>
                            <li class="list-group-item"><b>Designation: </b><?php echo e($employee->designation); ?> </li>
                            <li class="list-group-item"><b>Date of Join: </b><?php echo e($employee->joining_date); ?> </li>
                            <li class="list-group-item"><b>Subject Speciality: </b><?php echo e($employee->subject_speciality); ?> </li>
                            <li class="list-group-item"><b>Basic Salary: </b><?php echo e($employee->basic_salary); ?> </li>
                            <li class="list-group-item"><b>Education Qualification: </b><?php echo e($employee->education_qualification); ?> </li>
                            <li class="list-group-item"><b>User Type: </b><?php echo e($employee->user_type); ?> </li>
                            <li class="list-group-item"><b>Date of Birth: </b><?php echo e($employee->date_of_birth); ?> </li>
                            <li class="list-group-item"><b>National ID Number: </b><?php echo e($employee->nid); ?> </li>
                            <li class="list-group-item"><b>Blood Group: </b><?php echo e($employee->blood_group); ?> </li>

                            <li class="list-group-item"><b>Martial Status:</b>
                                <?php if($employee->marital_status=='1'): ?>
                                    Married
                                <?php else: ?>
                                    Unmarried
                                <?php endif; ?>
                            </li>

                            <li class="list-group-item"><b>Contact Number: </b><?php echo e($employee->contact_number.' ,'.$employee->contact_number2); ?> </li>
                            <li class="list-group-item"><b>Email: </b><?php echo e($employee->email); ?> </li>
                            <li class="list-group-item"><b>Father Name: </b><?php echo e($employee->father_name); ?> </li>
                            <li class="list-group-item"><b>Mother Name: </b><?php echo e($employee->mother_name); ?> </li>
                            <li class="list-group-item"><b>Emergency Number: </b><?php echo e($employee->emergency_number); ?> </li>
                            <li class="list-group-item"><b>Present Address: </b><?php echo e($employee->present_address); ?> </li>
                            <li class="list-group-item"><b>Permanent Address: </b><?php echo e($employee->permanent_address); ?> </li>
                        </ul>
                    </div>
                    <!-- END SIDEBAR USER TITLE -->

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-ms\resources\views/employee/employee_details.blade.php ENDPATH**/ ?>