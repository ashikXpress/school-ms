<!DOCTYPE html>
<html lang="en">
<!-- BEGIN HEAD -->
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta name="description" content="Responsive Admin Template" />
    <meta name="author" content="SmartUniversity" />
    <title>
        <?php if(isset($title)): ?>
            <?php echo e($title.' |'); ?>

        <?php endif; ?>

        <?php echo e(config('app.name')); ?>

    </title>
    <!-- google font -->
   <?php echo $__env->make('layouts.assets._styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<!-- END HEAD -->

<body
    class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md header-white white-sidebar-color logo-indigo">
<div class="page-wrapper">
    <!-- start header -->

    <?php echo $__env->make('layouts.assets._top_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <!-- end header -->
    <!-- start color quick setting -->

    <!-- end color quick setting -->
    <!-- start page container -->
    <div class="page-container">
        <!-- start sidebar menu -->

            <?php if(Auth::guard('employee')->check() && Auth::guard('employee')->user()->user_type=='admin'): ?>
                <?php echo $__env->make('layouts.assets._side_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif(Auth::guard('employee')->check() && Auth::guard('employee')->user()->user_type=='teacher'): ?>
                <?php echo $__env->make('layouts.assets._teacher_side_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>





        <!-- end sidebar menu -->
        <!-- start page content -->
        <div class="page-content-wrapper">
            <div class="page-content">
                <?php echo $__env->make('layouts.assets._header_msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
        <!-- end page content -->
        <!-- start chat sidebar -->

        <!-- end chat sidebar -->
    </div>
    <!-- end page container -->
    <!-- start footer -->
    <?php echo $__env->make('layouts.assets._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end footer -->
</div>
<!-- start js include path -->
<?php echo $__env->make('layouts.assets._scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- end js include path -->
</body>
</html>
<?php /**PATH C:\xampp\htdocs\school-ms\resources\views/layouts/master_layout.blade.php ENDPATH**/ ?>