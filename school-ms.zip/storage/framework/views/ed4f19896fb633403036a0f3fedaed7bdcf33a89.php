<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12 col-sm-12">
            <div class="card card-box">
                <div class="card-head">
                    <header>Employee join Form</header>
                    <button id="panel-button3"
                            class="mdl-button mdl-js-button mdl-button--icon pull-right"
                            data-upgraded=",MaterialButton">
                        <i class="material-icons">more_vert</i>
                    </button>
                    <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect"
                        data-mdl-for="panel-button3">
                        <li class="mdl-menu__item"><i class="material-icons">assistant_photo</i>Action
                        </li>
                        <li class="mdl-menu__item"><i class="material-icons">print</i>Another action
                        </li>
                        <li class="mdl-menu__item"><i class="material-icons">favorite</i>Something else
                            here</li>
                    </ul>
                </div>
                <div class="card-body " id="bar-parent2">
                    <form action="<?php echo e(route('employee.join')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="form-group col-md-6 col-sm-6">
                                <label for="first_name">First name</label>
                                <input type="text" name="first_name" value="<?php echo e(old('first_name')); ?>" id="first_name" class="form-control" placeholder="Enter first name">
                                <span class="text text-danger"><?php echo e($errors->first('first_name')); ?></span>
                            </div>
                            <div class="form-group col-md-6 col-sm-6">
                                <label for="last_name">Last name</label>
                                <input type="text" name="last_name" value="<?php echo e(old('last_name')); ?>" id="last_name" class="form-control" placeholder="Enter first name">
                                <span class="text text-danger"><?php echo e($errors->first('last_name')); ?></span>
                            </div>


                            <div class="form-group col-md-6 col-sm-6">
                                <label>User type</label>
                                <select class="form-control" name="user_type" id="employeeusertype">
                                    <option disabled selected>Selecte group</option>
                                    <option value="superadmin" <?php if(old('user_type') == 'superadmin'): ?>selected <?php endif; ?>>Super Admin</option>
                                    <option value="admin" <?php if(old('user_type') == 'admin'): ?>selected <?php endif; ?>>Admin</option>
                                    <option value="teacher" <?php if(old('user_type') == 'teacher'): ?>selected <?php endif; ?>>Teacher</option>
                                    <option value="staff" <?php if(old('user_type') == 'staff'): ?>selected <?php endif; ?>>Staff</option>
                                </select>
                                <span class="text text-danger"><?php echo e($errors->first('user_type')); ?></span>
                            </div>
                            <div class="form-group col-md-6 col-sm-6">
                                <label>Designation</label>
                                <select class="form-control" name="designation" id="designation">
                                    <option disabled selected>Selecte group</option>
                                    <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($designation->designation_name); ?>" <?php if(old('designation') == $designation->designation_name): ?>selected <?php endif; ?>><?php echo e($designation->designation_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text text-danger"><?php echo e($errors->first('designation')); ?></span>
                            </div>
                            <div class="form-group col-md-6 col-sm-6">
                                <label for="dp1">Date of birth</label>
                                <div class="input-append date" id="dp1">
                                    <input class="form-control formDatePicker" name="date_of_birth" value="<?php echo e(old('date_of_birth')); ?>"  placeholder="Enter date of birth" size="44" type="text" aria-invalid="false">
                                    <span class="add-on"><i class="fa fa-calendar"></i></span>
                                    <span class="text text-danger"><?php echo e($errors->first('date_of_birth')); ?></span>
                                </div>

                            </div>


                            <div class="form-group col-md-6 col-sm-6">
                                <label>Gender</label>
                                <div class="row col-md-12">
                                    <div class="radio p-0 col-md-3">
                                        <input type="radio" name="gender_name" id="optionsRadios1" value="0" <?php echo e(old('gender_name') == '0' ? 'checked' : ''); ?>>
                                        <label for="optionsRadios1">Male</label>
                                    </div>
                                    <div class="radio p-0 col-md-3">
                                        <input type="radio" name="gender_name"  id="optionsRadios2" value="1" <?php echo e(old('gender_name') == '1' ? 'checked' : ''); ?>>
                                        <label for="optionsRadios2">Female</label>
                                    </div>
                                </div>
                                <span class="text text-danger"><?php echo e($errors->first('gender_name')); ?></span>
                            </div>

                            <div class="form-group col-md-6 col-sm-6">
                                <label>Marital status</label>
                                <div class="row col-md-12">
                                    <div class="radio p-0 col-md-3">
                                        <input type="radio" name="marital_status" id="optionsRadios4" value="0" <?php echo e(old('marital_status') == '0' ? 'checked' : ''); ?>>
                                        <label for="optionsRadios4">Married</label>
                                    </div>
                                    <div class="radio p-0 col-md-3">
                                        <input type="radio" name="marital_status"  id="optionsRadios3" value="1" <?php echo e(old('marital_status') == '1' ? 'checked' : ''); ?>>
                                        <label for="optionsRadios3">Unmarried</label>
                                    </div>
                                </div>
                                <span class="text text-danger"><?php echo e($errors->first('marital_status')); ?></span>
                            </div>

                            <div class="form-group col-md-6 col-sm-6">
                                <label for="nid">National Identity</label>
                                <input type="number" name="nid" value="<?php echo e(old('nid')); ?>" id="nid" class="form-control" placeholder="Enter National Identity">
                                <span class="text text-danger"><?php echo e($errors->first('nid')); ?></span>
                            </div>
                            <div class="form-group col-md-6 col-sm-6">
                                <label>Blood group</label>
                                <select class="form-control" name="blood_group" id="bloodgroupselected">
                                    <option disabled selected>Selecte group</option>
                                    <option value="A+" <?php if(old('blood_group') == 'A+'): ?>selected <?php endif; ?>>A+</option>
                                    <option value="B+" <?php if(old('blood_group') == 'B+'): ?>selected <?php endif; ?>>B+</option>
                                    <option value="O+" <?php if(old('blood_group') == 'O+'): ?>selected <?php endif; ?>>O+</option>
                                    <option value="AB+" <?php if(old('blood_group') == 'AB+'): ?>selected <?php endif; ?>>AB+</option>

                                </select>
                                <span class="text text-danger"><?php echo e($errors->first('blood_group')); ?></span>
                            </div>




                            <div class="form-group col-md-6 col-sm-6">
                                <label for="education_qualification">Education qualification</label>
                                <textarea class="form-control" name="education_qualification" id="education_qualification"  rows="3" placeholder="Enter education qualification"><?php echo e(old('education_qualification')); ?></textarea>
                                <span class="text text-danger"><?php echo e($errors->first('education_qualification')); ?></span>
                            </div>
                            <div class="form-group col-md-6 col-sm-6">
                                <label for="father_name">Father's name</label>
                                <input type="text" name="father_name" value="<?php echo e(old('father_name')); ?>" id="father_name" class="form-control" placeholder="Enter father's name">
                                <span class="text text-danger"><?php echo e($errors->first('father_name')); ?></span>
                            </div>

                            <div class="form-group col-md-6 col-sm-6">
                                <label for="mother_name">Mother's name</label>
                                <input type="text" name="mother_name" value="<?php echo e(old('mother_name')); ?>" id="mother_name" class="form-control" placeholder="Enter mother's name">
                                <span class="text text-danger"><?php echo e($errors->first('mother_name')); ?></span>
                            </div>


                            <div class="form-group col-md-6 col-sm-6">
                                <label for="address">Address</label>
                                <textarea name="address" id="address" class="form-control" rows="3" placeholder="Enter address"><?php echo e(old('address')); ?></textarea>
                                <span class="text text-danger"><?php echo e($errors->first('address')); ?></span>
                            </div>
                            <div class="form-group col-md-6 col-sm-6">
                                <label for="address2">Address 2</label>
                                <textarea class="form-control" name="address2" id="address2"  rows="3" placeholder="Enter address 2"><?php echo e(old('address2')); ?></textarea>
                                <span class="text text-danger"><?php echo e($errors->first('address2')); ?></span>
                            </div>
                            <div class="form-group col-md-6 col-sm-6">
                                <label for="contact_number">Contact number</label>
                                <input type="number" name="contact_number" value="<?php echo e(old('contact_number')); ?>" id="contact_number" class="form-control" placeholder="Enter contact number">
                                <span class="text text-danger"><?php echo e($errors->first('contact_number')); ?></span>
                            </div>
                            <div class="form-group col-md-6 col-sm-6">
                                <label for="contact_number2">Contact number 2</label>
                                <input type="number" name="contact_number2" value="<?php echo e(old('contact_number2')); ?>" id="contact_number2" class="form-control" placeholder="Enter contact number 2">
                                <span class="text text-danger"><?php echo e($errors->first('contact_number2')); ?></span>
                            </div>
                            <div class="form-group col-md-6 col-sm-6">
                                <label for="dp2">Joining date</label>
                                <div class="input-append date" id="dp2">
                                    <input class="form-control formDatePicker" name="joining_date" value="<?php echo e(old('joining_date')); ?>"  placeholder="Enter joining date" size="44" type="text"   aria-invalid="false">
                                    <span class="add-on"><i class="fa fa-calendar"></i></span>
                                </div>
                                <span class="text text-danger"><?php echo e($errors->first('joining_date')); ?></span>

                            </div>
                            <div class="form-group col-md-6 col-sm-6">
                                <label for="basic_salary">Basic salary</label>
                                <input type="number" name="basic_salary" value="<?php echo e(old('basic_salary')); ?>" id="basic_salary" class="form-control" placeholder="Enter basic salary">
                                <span class="text text-danger"><?php echo e($errors->first('basic_salary')); ?></span>
                            </div>
                            <div class="form-group col-md-6 col-sm-6">
                                <label for="others_honorarium">Others honorarium</label>
                                <input type="number" name="others_honorarium" value="<?php echo e(old('others_honorarium')); ?>" id="others_honorarium" class="form-control" placeholder="Enter others honorarium">
                                <span class="text text-danger"><?php echo e($errors->first('others_honorarium')); ?></span>
                            </div>
                            <div class="form-group col-md-6 col-sm-6">
                                <label for="subject_speciality">Subject speciality</label>
                                <input type="text" name="subject_speciality" value="<?php echo e(old('subject_speciality')); ?>" id="subject_speciality" class="form-control" placeholder="Enter subject speciality">
                                <span class="text text-danger"><?php echo e($errors->first('subject_speciality')); ?></span>
                            </div>

                            <div class="form-group col-md-6 col-sm-6">
                                <label for="email">Email address</label>
                                <input type="email" name="email" value="<?php echo e(old('email')); ?>" id="email" class="form-control" placeholder="Enter email address">
                                <span class="text text-danger"><?php echo e($errors->first('email')); ?></span>
                            </div>
                            <div class="form-group col-md-6 col-sm-6">
                                <label for="password">Password</label>
                                <input type="password" name="password" value="<?php echo e(old('password')); ?>" id="password" class="form-control" placeholder="Enter Password">
                                <span class="text text-danger"><?php echo e($errors->first('password')); ?></span>
                            </div>
                            <div class="form-group col-md-6 col-sm-6">
                                <label for="retype_password">Retype password</label>
                                <input type="password" name="retype_password" value="<?php echo e(old('retype_password')); ?>" id="retype_password" class="form-control" placeholder="Enter retype password">
                                <span class="text text-danger"><?php echo e($errors->first('retype_password')); ?></span>
                            </div>

                            <div class="form-group col-md-12">
                                <div class="col-md-9">
                                    <button type="submit" class="btn btn-info btn-lg m-r-20">Submit</button>
                                    <a class="btn btn-default btn-lg">Cancel</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\school-ms\resources\views/employee/join_employee.blade.php ENDPATH**/ ?>