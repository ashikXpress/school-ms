<?php $__env->startSection('content'); ?>



    <div class="row">
        <div class="col-md-12 col-sm-12">
            <div class="card card-box">
                <div class="card-head">
                    <header>Create Objective Question</header>


                </div>
                <div class="card-body " id="bar-parent2">
                    <div class="col-md-12">
                        <form action="" class="row">
                            <div class="col-md-3 form-group margin-left">
                                <input type="number" name="quantity" class="form-control" placeholder="Question Quantity">
                            </div>
                           <div class="col-md-2">
                               <button type="submit" class="btn btn-info btn-lg m-r-20">Create</button>
                           </div>
                        </form>
                    </div>


                <?php if(isset($questions)): ?>
                    <form action="<?php echo e(route('create.objective.question')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <input type="hidden" value="<?php echo e($questions); ?>" name="question_qty">
                            <div class="form-group col-md-3 col-sm-3">
                                <label for="class">Class name</label>
                                <select class="form-control" name="class" id="class">
                                    <option disabled selected>Select class</option>
                                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($class->class_name); ?>" <?php if(old('class') == $class->class_name): ?>selected <?php endif; ?>><?php echo e($class->class_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text text-danger"><?php echo e($errors->first('class')); ?></span>
                            </div>
                            <div class="form-group col-md-3 col-sm-3">
                                <label for="subject">Subject name</label>
                                <select class="form-control" name="subject" id="class">
                                    <option disabled selected>Select class</option>
                                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($subject->subject_name); ?>" <?php if(old('subject') == $subject->subject_name): ?>selected <?php endif; ?>><?php echo e($subject->subject_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text text-danger"><?php echo e($errors->first('subject')); ?></span>
                            </div>
                            <div class="form-group col-md-3 col-sm-3">
                                <label for="subject">Exam term name</label>
                                <select class="form-control" name="exam_term" id="class">
                                    <option disabled selected>Select class</option>
                                    <?php $__currentLoopData = $exam_terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($term->exam_term_name); ?>" <?php if(old('exam_term') == $term->exam_term_name): ?>selected <?php endif; ?>><?php echo e($term->exam_term_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text text-danger"><?php echo e($errors->first('exam_term')); ?></span>
                            </div>

                            <div class="form-group col-md-3 col-sm-3">
                                <label for="academic_year">Academic year</label>
                                <input type="text" name="academic_year" value="<?php echo e(old('academic_year')); ?>" id="academic_year" class="form-control yearpicker" placeholder="Academic year">
                                <span class="text text-danger"><?php echo e($errors->first('academic_year')); ?></span>
                            </div>

                            <div class="col-md-12">
                                    <?php for($i=1; $i<=$questions;$i++): ?>
                                   <div class="col-md-12 form-group">
                                       <label for="qty_<?php echo e($i); ?>"><?php echo e($i); ?>. Question name</label>
                                       <input type="text" id="qty_<?php echo e($i); ?>" name="objective_question_name_<?php echo e($i); ?>" value="<?php echo e(old('objective_question_name_'.$i)); ?>" class="form-control" placeholder="Objective question name">
                                       <span class="text text-danger"><?php echo e($errors->first('objective_question_name_'.$i)); ?></span>
                                       <br>
                                       <div class="row">
                                           <div class="col-md-3 form-group">
                                               <input type="text" name="option_a_<?php echo e($i); ?>" value="<?php echo e(old('option_a_'.$i)); ?>"  class="form-control" placeholder="Option A">
                                                <span class="text text-danger"><?php echo e($errors->first('option_a_'.$i)); ?></span>
                                           </div>
                                           <div class="col-md-3 form-group">
                                               <input type="text" name="option_b_<?php echo e($i); ?>" value="<?php echo e(old('option_b_'.$i)); ?>"  class="form-control" placeholder="Option B">
                                               <span class="text text-danger"><?php echo e($errors->first('option_b_'.$i)); ?></span>
                                           </div>
                                           <div class="col-md-3 form-group">
                                               <input type="text" name="option_c_<?php echo e($i); ?>" value="<?php echo e(old('option_c_'.$i)); ?>" class="form-control" placeholder="Option C">
                                               <span class="text text-danger"><?php echo e($errors->first('option_c_'.$i)); ?></span>
                                           </div>
                                           <div class="col-md-3 form-group">
                                               <input type="text" name="option_d_<?php echo e($i); ?>" value="<?php echo e(old('option_d_'.$i)); ?>" class="form-control" placeholder="Option D">
                                               <span class="text text-danger"><?php echo e($errors->first('option_d_'.$i)); ?></span>
                                           </div>
                                       </div>
                                   </div>
                                    <?php endfor; ?>

                            </div>



                            <div class="form-group col-md-12">
                                <div class="col-md-9">
                                    <button type="submit" class="btn btn-info btn-lg m-r-20">Create Objective Question</button>

                                    <a href="<?php echo e(route('objective.question.list')); ?>" class="btn btn-default btn-lg">Cancel</a>
                                </div>
                            </div>
                        </div>
                    </form>
                <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-ms\resources\views/question/create_objective_questions.blade.php ENDPATH**/ ?>