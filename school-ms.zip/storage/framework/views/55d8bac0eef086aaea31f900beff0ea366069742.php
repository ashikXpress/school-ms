<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card card-topline-aqua">
                <div class="card-head">
                    <header>Employee Payments</header>
                    <div class="tools">
                        <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
                        <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
                        <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                    </div>
                </div>
                <div class="card-body ">
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-6">
                            <div class="btn-group">
                                <a href="<?php echo e(route('employee.payment.form')); ?>" id="addRow" class="btn btn-info">
                                    Add Payment <i class="fa fa-plus"></i>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-6">
                            <div class="btn-group pull-right">
                                <a class="btn deepPink-bgcolor  btn-outline dropdown-toggle" data-toggle="dropdown">Tools
                                    <i class="fa fa-angle-down"></i>
                                </a>
                                <ul class="dropdown-menu pull-right">
                                    <li>
                                        <a href="javascript:;">
                                            <i class="fa fa-print"></i> Print </a>
                                    </li>
                                    <li>
                                        <a href="javascript:;">
                                            <i class="fa fa-file-pdf-o"></i> Save as
                                            PDF </a>
                                    </li>
                                    <li>
                                        <a href="javascript:;">
                                            <i class="fa fa-file-excel-o"></i>
                                            Export to Excel </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="table-scrollable">
                            <div class="row">
                                <div class="col-sm-12">
                                    <table id="example1" class="display dataTable no-footer" style="width: 100%;" role="grid" aria-describedby="example1_info">
                                        <thead>
                                        <tr role="row">
                                            <th>Sl</th>
                                            <th>Name</th>
                                            <th>Type</th>
                                            <th>Date</th>
                                            <th>Receipt no</th>
                                            <th>Salary</th>
                                            <th>Honorarium</th>
                                            <th>Payment by</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="gradeX odd" role="row">
                                                <td class="left"><?php echo e($loop->iteration); ?></td>
                                                <td class="left"><?php echo e($payment->employee->first_name.' '.$payment->employee->last_name); ?></td>
                                                <td class="left"><?php echo e($payment->payment_type); ?></td>
                                                <td class="left"><?php echo e($payment->payment_date); ?></td>
                                                <td class="left"><?php echo e($payment->receipt_no); ?></td>
                                                <td class="left"><?php echo e($payment->basic_salary.' BDT'); ?></td>
                                                <td class="left"><?php echo e($payment->others_honorarium.' BDT'); ?></td>
                                                <td class="left"><?php echo e($payment->paymentBy->first_name.' '.$payment->paymentBy->last_name); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('employee.payment.edit',$payment->id)); ?>" class="btn btn-primary btn-xs">
                                                        <i class="fa fa-pencil"></i>
                                                        Edit
                                                    </a>
                                                    <button class="btn btn-danger btn-xs">
                                                        <i class="fa fa-trash-o "></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12 col-md-5">
                                    <div class="dataTables_info" id="example4_info" role="status" aria-live="polite">Showing <?php echo e($payments->count()); ?> of <?php echo e($counts); ?> entries</div>
                                </div>
                                <div class="col-sm-12 col-md-7">
                                    <?php echo e($payments->links()); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-ms\resources\views/payment/employee_payment_list.blade.php ENDPATH**/ ?>