<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12 col-sm-12">
            <div class="card card-box">
                <div class="card-head">
                    <header>Create class subject</header>
                </div>
                <div class="card-body " id="bar-parent2">
                    <form action="<?php echo e(route('create.class.subject')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">

                            <div class="form-group col-md-2 col-sm-2">
                                <label for="class">Class name</label>
                                <select class="form-control classname" name="class" id="class">
                                    <option disabled selected>Select class</option>
                                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($class->class_name); ?>" <?php if(old('class') == $class->class_name): ?>selected <?php endif; ?>><?php echo e($class->class_name); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <span class="text text-danger"><?php echo e($errors->first('class')); ?></span>
                            </div>
                            <div class="form-group col-md-2 col-sm-2">
                                <label for="academic_year">Academic year</label>
                                <input type="text" name="academic_year" value="<?php echo e(old('academic_year')); ?>" id="academic_year" class="form-control yearpicker" placeholder="Academic year">
                                <span class="text text-danger"><?php echo e($errors->first('academic_year')); ?></span>
                            </div>




                            <div class="form-group col-md-12">
                               <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="subject_code[<?php echo e($key); ?>]" value="<?php echo e($subject->subject_code); ?>">

                                    <label class="rt-chkbox rt-chkbox-single rt-chkbox-outline col-md-7">

                                <div class="subject"><?php echo e($loop->iteration.' . '); ?> <?php echo e($subject->subject_name); ?> <div class="subject_code"><?php echo e($subject->subject_code); ?></div></div>
                                   <input type="checkbox" name="subjects[]" class="checkboxes" value="<?php echo e(strtolower(str_replace(' ', '_', $subject->subject_name))); ?>">
                                    <span></span>

                               </label>

                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                           </div>


                            <div class="form-group col-md-12">
                                <div class="col-md-9">
                                    <button type="submit" class="btn btn-info  m-r-20">Create class subject</button>
                                    <a class="btn btn-default">Cancel</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-ms\resources\views/academic/create_class_subject.blade.php ENDPATH**/ ?>