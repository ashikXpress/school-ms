<?php $__env->startSection('content'); ?>

    <h1>hello staff</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-ms\resources\views/staff/staff_dashboard.blade.php ENDPATH**/ ?>