<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 col-sm-12">
            <div class="card card-box">
                <div class="card-head">
                    <header>Create syllabus</header>

                </div>
                <div class="card-body " id="bar-parent2">
                    <form action="<?php echo e(route('create.syllabus')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="form-group col-md-3 col-sm-3">
                                <label for="class">Class name</label>
                                <select class="form-control" name="class" id="class">
                                <option disabled selected>Select class</option>
                                <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($class->class_name); ?>" <?php if(old('class') == $class->class_name): ?>selected <?php endif; ?>><?php echo e($class->class_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text text-danger"><?php echo e($errors->first('class')); ?></span>
                            </div>
                            <div class="form-group col-md-3 col-sm-3">
                                <label for="subject">Subject name</label>
                                <select class="form-control" name="subject" id="class">
                                    <option disabled selected>Select class</option>
                                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($subject->subject_name); ?>" <?php if(old('subject') == $subject->subject_name): ?>selected <?php endif; ?>><?php echo e($subject->subject_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text text-danger"><?php echo e($errors->first('subject')); ?></span>
                            </div>
                            <div class="form-group col-md-3 col-sm-3">
                                <label for="subject">Exam term name</label>
                                <select class="form-control" name="exam_term_name" id="class">
                                    <option disabled selected>Select class</option>
                                    <?php $__currentLoopData = $exam_terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($term->exam_term_name); ?>" <?php if(old('exam_term_name') == $term->exam_term_name): ?>selected <?php endif; ?>><?php echo e($term->exam_term_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text text-danger"><?php echo e($errors->first('exam_term_name')); ?></span>
                            </div>

                            <div class="form-group col-md-3 col-sm-3">
                                <label for="academic_year">Academic year</label>
                                <input type="text" name="academic_year" value="<?php echo e(old('academic_year')); ?>" id="academic_year" class="form-control yearpicker" placeholder="Academic year">
                                <span class="text text-danger"><?php echo e($errors->first('academic_year')); ?></span>
                            </div>



                            <div class="form-group col-md-12 col-sm-12">
                                <label for="summernote">Description</label>

                                <textarea class="form-control" name="description" id="summernote" placeholder="Enter description" cols="30" rows="10">
                                <?php echo e(old('description')); ?>

                                </textarea>
                                <span class="text text-danger"><?php echo e($errors->first('description')); ?></span>
                            </div>

                            <div class="form-group col-md-12">
                                <div class="col-md-9">
                                    <button type="submit" class="btn btn-info btn-lg m-r-20">Create syllabus</button>
                                    <a href="<?php echo e(route('syllabus.list')); ?>" class="btn btn-default btn-lg">Cancel</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-ms\resources\views/syllabus/create_syllabus.blade.php ENDPATH**/ ?>