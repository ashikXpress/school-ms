<?php $__env->startSection('content'); ?>

    <!-- panel-login start -->
    <div class="authfy-panel panel-login text-center active">

        <div class="authfy-heading">
            <h3 class="auth-title">Recover your password</h3>
            <p>Fill in your e-mail address below and we will send you an email with further instructions.</p>
            <?php if(session()->has('error')): ?>
                <span class="text text-danger">
                             <?php echo e(session()->get('error')); ?>

                         </span>
            <?php endif; ?>

        </div>

        <!-- social login buttons start -->

        <div class="row">
            <div class="col-xs-12 col-sm-12">
                <form  class="loginForm" action="<?php echo e(route('employee.reset.password')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <input type="email" class="form-control email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email address">
                    <span class="text text-danger"><?php echo e($errors->first('email')); ?></span>
                    <br>

                    <div class="row remember-row">

                        <div class="col-xs-6 col-sm-6 col-md-offset-6">
                            <p class="forgotPwd">

                                <a  href="<?php echo e(route('login.form')); ?>">Login to your account?</a>

                            </p>
                        </div>
                    </div> <!-- ./remember-row -->
                    <div class="form-group">
                        <button class="btn btn-lg btn-primary btn-block" type="submit">Login with email</button>
                    </div>

                </form>
            </div>
        </div>
    </div> <!-- ./panel-login -->







<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.employee_auth_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-ms\resources\views/admin/auth/password_recovery.blade.php ENDPATH**/ ?>
