<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <!-- BEGIN PROFILE CONTENT -->
            <div class="profile-content">
                <div class="row">
                    <div class="card col-md-12">
                        <div class="card-topline-aqua">
                            <div class="profile-usertitle">
                                <div class="profile-usertitle-name">Academic year -<?php echo e($question->academic_year); ?></div>
                                <p> <strong>Class: <?php echo e($question->class); ?></strong> </p>
                                <p><strong>Subject: <?php echo e($question->subject); ?></strong></p>
                                <p><strong>Examination: <?php echo e($question->examination_term); ?></strong></p>
                                <hr>
                            </div>

                        </div>
                        <div class="white-box" style="color:#000 !important">

                            <div class="tab-content">
                                <div class="tab-pane active fontawesome-demo">
                                    <div id="biography">

                                        <article><?php echo html_entity_decode($question->creative_question); ?></article>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END PROFILE CONTENT -->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-ms\resources\views/question/creative_question_details.blade.php ENDPATH**/ ?>