<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card card-topline-red">
                <div class="card-head">
                    <header>Students Examination Marks</header>

                </div>
                <div class="card-body " >
                    <form class="row" action="">

                        <div class="form-group col-md-3 col-sm-3">
                            <label for="class">Student</label>
                            <select class="form-control" name="student" id="class" required>
                                <option disabled selected>Select</option>
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($student->id_number); ?>"><?php echo e($student->id_number.' ('.$student->first_name.' '.$student->last_name.')'); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="text text-danger"><?php echo e($errors->first('subject')); ?></span>
                        </div>


                        <div class="col-md-2 padd-less">

                            <button type="submit" class=" btn btn-info">Search</button>

                        </div>

                    </form>
                    <hr>

                    <?php if(isset($subjects)): ?>
                    <form action="<?php echo e(route('insert.student.marks')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                    <div class="col-md-12">
                        <div class="row">
                            <input type="hidden" name="student_id" value="<?php echo e($std->id); ?>">
                            <div class="col-md-2">Name: <?php echo e($std->first_name.' '.$std->last_name); ?></div>
                            <div class="col-md-2">Class: <?php echo e($std->class); ?></div>
                            <div class="col-md-2">Id number: <?php echo e($std->id_number); ?></div>
                            <div class="form-group col-md-1">
                                <label for="subject">Exam term</label>

                            </div>
                            <div class="form-group col-md-2">
                                <select class="form-control" name="exam_term" id="class">
                                    <option disabled selected>Select</option>
                                    <?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($term->exam_term_name); ?>" <?php if(old('exam_term') == $term->exam_term_name): ?>selected <?php endif; ?>><?php echo e($term->exam_term_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text text-danger"><?php echo e($errors->first('exam_term')); ?></span>
                            </div>
                            <div class="form-group col-md-1">
                                <label for="academic_year">Session</label>

                            </div>
                            <div class="form-group col-md-2 col-sm-">

                                <input type="text" name="academic_year" value="<?php echo e(old('academic_year')); ?>" id="academic_year" class="form-control yearpicker" placeholder="Academic year">
                                <span class="text text-danger"><?php echo e($errors->first('academic_year')); ?></span>
                            </div>

                        </div>
                    </div>
                    <hr>
                    <div class="row">

                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="form-group col-md-2">
                                    <label for="marks[<?php echo e($key); ?>]"><?php echo e($loop->iteration.'. '); ?><?php echo e(strtoupper(str_replace('_', ' ', $subject->subject_name))); ?><?php echo e($subject->subject_code); ?></label>

                                </div>
                                <div class="form-group col-md-3">
                                    <input type="number" name="marks[<?php echo e($key); ?>]" value="<?php echo e(old('marks.'.$key)); ?>" id="marks[<?php echo e($key); ?>]" class="form-control" placeholder="Marks">
                                    <input type="hidden" name="subjects[]" value="<?php echo e($subject->subject_name); ?>">
                                </div>


                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-md-9">
                                <button type="submit" class="btn btn-info btn-lg m-r-20">Insert marks</button>
                                <a class="btn btn-default btn-lg">Cancel</a>
                            </div>

                    </div>

                    </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-ms\resources\views/result/student_marks.blade.php ENDPATH**/ ?>