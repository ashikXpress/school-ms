
<div class="title m-b-md">
    You cannot access this page! This is for only '<?php echo e($role); ?>'"
</div>
<?php /**PATH C:\xampp\htdocs\school-ms\resources\views/unauthorized.blade.php ENDPATH**/ ?>