<?php $__env->startSection('content'); ?>



    <!-- Banner -->
    <div id="blog_banner">
        <div class="page-title">
            <div class="container">
                <h2>My Account</h2>
            </div>
        </div>
        <div class="black-overlay"></div>
    </div>
    <!-- End banner -->

    <!-- breadcrumb -->
    <div class="breadcrumb-main">
        <div class="container">
            <ul class="breadcrumb">
                <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="active">Log In</li>
            </ul>
        </div>
    </div>
    <!-- End breadcrumb -->


    <!-- cart -->
    <section id="account" class="account section-inner">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3 col-xs-12">
                    <div class="account-inner">
                        <!-- section title -->
                        <div class="inner-heading">
                            <h3>Sign In</h3>
                        </div>
                        <form action="<?php echo e(route('student.login')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="email">Username/Email Address:</label>
                                <input type="email" class="form-control" placeholder="Enter your emil/ID number" name="email" id="email">
                                <span class="text text-danger"><?php echo e($errors->first('email')); ?></span>
                            </div>
                            <div class="form-group">
                                <label for="password">Password:</label>
                                <input type="Password" class="form-control" placeholder="Enter your password" name="password" id="password">
                                <span class="text text-danger"><?php echo e($errors->first('password')); ?></span>
                            </div>
                            <div class="form-group">
                                <button class="mt_btn_yellow">Login</button>
                                <input class="checkbox" type="checkbox"> <span>Remember me</span>
                            </div>
                            <p class="lost_password">
                                <a href="<?php echo e(route('student.password.recovery.form')); ?>">Lost your password?</a>
                            </p>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- End store -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-ms\resources\views/fontend/student_login.blade.php ENDPATH**/ ?>