<?php

namespace App\Http\Controllers\Guardain;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class GuardainController extends Controller
{
    //
}
