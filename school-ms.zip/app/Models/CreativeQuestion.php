<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CreativeQuestion extends Model
{
    protected $guarded=[];
    protected $table='creative_question';
}
