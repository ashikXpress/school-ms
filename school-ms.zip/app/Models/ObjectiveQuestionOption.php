<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ObjectiveQuestionOption extends Model
{
    protected $guarded=[];
    protected $table='objective_question_options';
}
