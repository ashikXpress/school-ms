$(function () {
	$('#dp1').datepicker({
		format: 'D-M-Y'
	});
	$('#dp2').datepicker({
		format: 'D-M-Y'
	});
	$('#dp3').datepicker({
		format: 'D-M-Y'
	});

});
