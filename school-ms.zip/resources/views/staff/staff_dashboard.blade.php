@extends('layouts.master_layout')
@section('content')

    <h1>hello staff</h1>
@endsection
